<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class OrderItem extends Model
{
    use HasFactory;

    protected $guarded = ['id'];

    // Relasi: OrderItem milik 1 Product
    public function product()
    {
        return $this->belongsTo(Product::class);
    }
}